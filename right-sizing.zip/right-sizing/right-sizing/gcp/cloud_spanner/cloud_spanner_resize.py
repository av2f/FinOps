#! /usr/bin/env python

# for this setup, using service account key from local machine to connect to gcp

#imports needed
from google.cloud import spanner_admin_instance_v1
from google.protobuf import field_mask_pb2
import pandas as pd
import logging

# Configure logging
logging.basicConfig(filename='cloud_spanner_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read the CSV file
csv_file = 'cloud_spanner_resize.csv'
cloud_spanner_data = pd.read_csv(csv_file)

def resize_cloud_spanner_instance(project_id, instance_id, node_count):
    try:
        logging.info(f"attempting to update cloud spanner '{instance_id}'")
    
        #initiate client
        client = spanner_admin_instance_v1.InstanceAdminClient()

        # Define the instance name
        instance_name = f"projects/{project_id}/instances/{instance_id}"

        # Get the current instance configuration
        instance = client.get_instance(name=instance_name)
        
        # Update the instance's node count
        instance.node_count = node_count
        
        # Create the update mask to specify that we are updating the node count
        update_mask = field_mask_pb2.FieldMask(paths=["node_count"])

        # Create the UpdateInstanceRequest
        request = {
            "instance": instance,
            "field_mask": update_mask
        }
        
        # Execute the update
        operation = client.update_instance(request=request)

        # Wait for the operation to complete
        operation.result()
        logging.info(f"Successfully resized Cloud Spanner instance '{instance_id}' to {node_count} nodes.")
    
    except Exception as e:
        logging.error(f"Error occurred while updating cloud spanner : {str(e)}")

# Iterate over each row in the CSV file and inject values
for index, row in cloud_spanner_data.iterrows():
    resize_cloud_spanner_instance(
        row['project_id'],
        row['instance_id'],
        row['node_count'],
    )