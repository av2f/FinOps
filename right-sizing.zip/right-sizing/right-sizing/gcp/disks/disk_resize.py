#! /usr/bin/env python

# for this setup, using service account key from local machine to connect to gcp

#imports needed
import pandas as pd
from google.cloud import compute_v1
import logging

# Configure logging
logging.basicConfig(filename='disk_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read the CSV file
csv_file = 'disk_resize.csv'
disk_data = pd.read_csv(csv_file)

# Function to resize disk
def create_snapshot(project_id, zone, disk_name, snapshot_name):
    try:
        logging.info(f"creating snapshot '{snapshot_name}' from {disk_name} in zone '{zone}'")

        # Initialize the client
        client = compute_v1.DisksClient()

        # create snapshot
        snapshot = compute_v1.Snapshot(
        name=snapshot_name,
    )

    # Execute snapshot creation
        operation = client.create_snapshot(
        project=project_id,
        zone=zone,
        disk=disk_name,
        snapshot_resource=snapshot,
    )
        operation.result()
        logging.info(f"Successfully created snapshot '{snapshot_name}'")
    except Exception as e:
        logging.error(f"Error occurred while creating snapshot '{snapshot_name}': {str(e)}")

def create_new_disk(project_id, zone, disk_name, snapshot_name, new_disk_name, size):
    try:
        logging.info(f"creating disk '{new_disk_name}'")

        # Initialize the client
        client = compute_v1.DisksClient()

       # Define the disk object
        disk = compute_v1.Disk(
        name=new_disk_name,
        size_gb=size,
        source_snapshot=f"projects/{project_id}/global/snapshots/{snapshot_name}"
        )

        # Create the disk
        operation = client.insert(
        project=project_id,
        zone=zone,
        disk_resource=disk,
        )

        operation.result()
        logging.info(f"Successfully created new disk '{new_disk_name}'")

    except Exception as e:
        logging.error(f"Error occurred while creating new disk '{new_disk_name}': {str(e)}")

def delete_old_disk(project_id, zone, disk_name, snapshot_name, new_disk_name, size):
    try:
        logging.info(f"deleting disk '{disk_name}'")

        # Initialize the client
        client = compute_v1.DisksClient()

        # delete the old disk
        operation = client.delete(
        project=project_id,
        zone=zone,
        disk=disk_name,
        )

        operation.result()
        logging.info(f"Successfully deleted old disk '{disk_name}'")

    except Exception as e:
        logging.error(f"Error occurred while deleting old disk '{disk_name}': {str(e)}")

# Iterate over each row in the CSV file and inject values
for index, row in disk_data.iterrows():
    create_snapshot(
        row['project_id'],
        row['zone'],
        row['disk_name'],
        row['snapshot_name'],
    )
    create_new_disk(
        row['project_id'],
        row['zone'],
        row['disk_name'],
        row['snapshot_name'],
        row['new_disk_name'],
        row['size'],
    )
    delete_old_disk(
        row['project_id'],
        row['zone'],
        row['disk_name'],
        row['snapshot_name'],
        row['new_disk_name'],
        row['size'],
    )

