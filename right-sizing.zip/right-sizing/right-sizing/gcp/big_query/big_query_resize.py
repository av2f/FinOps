#! /usr/bin/env python

# for this setup, using service account key from local machine to connect to gcp

#imports needed
import pandas as pd
from google.cloud import bigquery
import logging

# Configure logging
logging.basicConfig(filename='bigquery_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read the CSV file
csv_file = 'big_query_resize.csv'
bigquery_data = pd.read_csv(csv_file)

def create_table(project_id, dataset_id, table_id):
    
    try:
        logging.info(f"creating a table '{table_id}' in '{dataset_id}'")
        # Initialize the BigQuery client
        client = bigquery.Client(project=project_id)
        
        # Define the table schema
        schema = [
            bigquery.SchemaField("name", "STRING", mode="REQUIRED"),
            bigquery.SchemaField("age", "INTEGER", mode="NULLABLE"),
            bigquery.SchemaField("timestamp", "TIMESTAMP", mode="NULLABLE"),
        ]
        
        # Define the table reference
        table_ref = client.dataset(dataset_id).table(table_id)

        # Create a table object with the specified schema
        table = bigquery.Table(table_ref, schema=schema)
        
        # Create the table
        table = client.create_table(table)
        logging.info(f"Successfully created new talbe '{table_id}'")

    except Exception as e:
        logging.error(f"Error occurred creating table '{table_id}': {str(e)}")

# Iterate over each row in the CSV file and inject values
for index, row in bigquery_data.iterrows():
    create_table(
        row['project_id'],
        row['dataset_id'],
        row['table_id'],
    )
