#! /usr/bin/env python

# for this setup, using service account key from local machine to connect to gcp

#imports needed
from googleapiclient import discovery
import pandas as pd
import logging

# Configure logging
logging.basicConfig(filename='postgres_db_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read the CSV file
csv_file = 'postgres_db_resize.csv'
postgres_data = pd.read_csv(csv_file)

def update_postgres(project_id, db_name, db_size):
    try:
        logging.info(f"update postgres '{db_name}'")
    
        # Initialize the Cloud SQL Admin client
        service = discovery.build('sqladmin', 'v1')

        body = {
            'settings': {
                'tier': db_size,
            }
        }

        # Execute change
        request = service.instances().patch(project=project_id, instance=db_name, body=body)
        response = request.execute()
        logging.info(f"updating postgres instance to '{db_size}'")
    
    except Exception as e:
        logging.error(f"Error occurred while updating postgres : {str(e)}")

# Iterate over each row in the CSV file and inject values
for index, row in postgres_data.iterrows():
    update_postgres(
        row['project_id'],
        row['db_name'],
        row['db_size'],
    )