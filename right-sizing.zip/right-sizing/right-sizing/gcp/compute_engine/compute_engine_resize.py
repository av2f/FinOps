#! /usr/bin/env python

# for this setup, using service account key from local machine to connect to gcp

#imports needed
import pandas as pd
from google.cloud import compute_v1
import logging

# Configure logging
logging.basicConfig(filename='compute_engine_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read the CSV file
csv_file = 'compute_engine_resize.csv'
compute_data = pd.read_csv(csv_file)

# Function to stop compute engine instance
def stop_compute_engine(project_id, zone, instance_name):
    try:
        logging.info(f"Attempting to stop compute engine '{instance_name}' in project '{project_id}'")

        # Init Client
        instance_client = compute_v1.InstancesClient()

        # Stop Instance parameters
        request = compute_v1.StopInstanceRequest(
            project=project_id,
            zone=zone,
            instance=instance_name,
        )
        # stop instance
        operation = instance_client.stop(request=request)
        operation.result()
        logging.info(f"Success in stopping compute engine '{instance_name}' in project '{project_id}'")
    
    except Exception as e:
        logging.error(f"Error stopping compute engine '{instance_name}': {str(e)}")

def update_compute_engine(project_id, zone, instance_name, machine_type):
    try:
        logging.info(f"Attempting to update compute engine '{instance_name}' in project '{project_id}'")

        # Init Client
        instance_client = compute_v1.InstancesClient()

        # Update Instance parameters
        request = compute_v1.SetMachineTypeInstanceRequest(
            project=project_id,
            zone=zone,
            instance=instance_name,
            instances_set_machine_type_request_resource=compute_v1.InstancesSetMachineTypeRequest(machine_type=machine_type),
        )
        # update instance
        operation = instance_client.set_machine_type(request=request)
        operation.result()
        logging.info(f"Success in updating compute engine '{instance_name}' in project '{project_id}'")
    
    except Exception as e:
        logging.error(f"Error updating compute engine '{instance_name}': {str(e)}")

def start_compute_engine(project_id, zone, instance_name):
    try:
        logging.info(f"Attempting to start compute engine '{instance_name}' in project '{project_id}'")

        # Init Client
        instance_client = compute_v1.InstancesClient()

        # Start Instance parameters
        request = compute_v1.StartInstanceRequest(
            project=project_id,
            zone=zone,
            instance=instance_name,
        )
        # start instance
        operation = instance_client.start(request=request)
        operation.result()
        logging.info(f"Success in starting compute engine '{instance_name}' in project '{project_id}'")
    
    except Exception as e:
        logging.error(f"Error stopping compute engine '{instance_name}': {str(e)}")

# Iterate over each row in the CSV file and inject values
for index, row in compute_data.iterrows():
    stop_compute_engine(
        row['project_id'],
        row['zone'],
        row['instance_name'],
    )
    update_compute_engine(
        row['project_id'],
        row['zone'],
        row['instance_name'],
        row['machine_type'],
    )
    start_compute_engine(
        row['project_id'],
        row['zone'],
        row['instance_name'],
    )

