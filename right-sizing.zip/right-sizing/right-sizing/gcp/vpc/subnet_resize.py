#! /usr/bin/env python

# for this setup, using service account key from local machine to connect to gcp

#imports needed
import pandas as pd
from google.cloud import compute_v1
import logging

# Configure logging
logging.basicConfig(filename='subnet_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read the CSV file
csv_file = 'subnet_resize.csv'
subnet_data = pd.read_csv(csv_file)

# Function to add a subnet
def update_subnet(project_id, region, vpc_name, subnet_name, subnet_prefix):
    try:
        logging.info(f"Attempting to add another subnet to vpc '{vpc_name}' in project '{project_id}'")

        # Init Client
        subnet_client = compute_v1.SubnetworksClient()

        # Prepare the subnet resource
        new_subnetwork = compute_v1.Subnetwork(
            name=subnet_name,
            ip_cidr_range=subnet_prefix,  # CIDR range for the new subnet
            network=f"projects/{project_id}/global/networks/{vpc_name}",  # VPC network
            region=region
        )
        
        # Create a request object for the insert operation
        request = compute_v1.InsertSubnetworkRequest(
            project=project_id,
            region=region,
            subnetwork_resource=new_subnetwork
        )

        operation = subnet_client.insert(request=request)
        operation.result()
        logging.info(f"Success in adding subnet '{subnet_name}' in vpc '{vpc_name}'")
    
    except Exception as e:
        logging.error(f"Error adding subnet to '{vpc_name}': {str(e)}")

# Iterate over each row in the CSV file and inject values
for index, row in subnet_data.iterrows():
    update_subnet(
        row['project_id'],
        row['region'],
        row['vpc_name'],
        row['subnet_name'],
        row['subnet_prefix'],
    )


