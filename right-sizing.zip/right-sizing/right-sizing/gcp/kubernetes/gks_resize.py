#!/usr/bin/env python

# for this setup, using service account key from local machine to connect to gcp

#imports needed
from google.cloud import container_v1
import pandas as pd
import logging

# Configure logging
logging.basicConfig(filename='gke_resize.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read the CSV file
csv_file = 'gks_resize.csv'
gks_data = pd.read_csv(csv_file)

def resize_gke_node_pool(project_id, zone, cluster_id, node_pool_id, new_node_count):
    try:
        logging.info(f"Attempting to resize node pool '{node_pool_id}' in cluster '{cluster_id}' to {new_node_count} nodes.")

        # Initialize the ClusterManagerClient
        client = container_v1.ClusterManagerClient()

        # Build the full location (project, zone, cluster)
        node_pool_path = f"projects/{project_id}/locations/{zone}/clusters/{cluster_id}/nodePools/{node_pool_id}"

        # Set the desired node count
        request = container_v1.SetNodePoolSizeRequest(
            name=node_pool_path,
            node_count=new_node_count
        )

        # Send the request to resize the node pool
        operation = client.set_node_pool_size(request=request)
        
        logging.info(f"Successfully resized node pool '{node_pool_id}' to {new_node_count} nodes.")

    except Exception as e:
        logging.error(f"Error occurred while resizing the node pool: {str(e)}")

# Iterate over each row in the CSV file and inject values
for index, row in gks_data.iterrows():
    resize_gke_node_pool(
        row['project_id'],
        row['zone'],
        row['cluster_id'],
        row['node_pool_id'],
        row['new_node_count'],
    )

