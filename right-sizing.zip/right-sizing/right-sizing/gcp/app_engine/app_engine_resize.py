#!/usr/bin/env python

# for this setup, using service account key from local machine to connect to gcp

#imports needed
from google.api_core.exceptions import GoogleAPIError
from google.cloud import appengine_admin_v1
from google.protobuf import field_mask_pb2
import pandas as pd
import logging

# Configure logging
logging.basicConfig(filename='app_engine_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Read the CSV file
csv_file = 'app_engine_resize.csv'
app_engine_data = pd.read_csv(csv_file)

def rightsize_app_engine_service(project_id, service_id, instance_class, version_id):
    try:
        logging.info(f"Attempting to rightsize App Engine service '{service_id}' with instance class '{instance_class}'.")

         # Initialize the App Engine Admin client
        client = appengine_admin_v1.VersionsClient()

        # Define the version name
        version_name = "apps/{project_id}/services/{service_id}/versions/{version_id}"

         # Check that the retrieved version object is valid
        if not isinstance(version_name, appengine_admin_v1.Version):
            raise TypeError("Retrieved object is not of type 'Version'")

        # Update the instance class
        version_name.instance_class = instance_class
        version_name.automatic_scaling = appengine_admin_v1.AutomaticScaling(
            min_instances=1,
            max_instances=10
        )

        # Create the field mask to specify which fields to update
        update_mask = field_mask_pb2.FieldMask(paths=['instance_class', 'automatic_scaling'])

        # Prepare the update request
        update_request = appengine_admin_v1.UpdateVersionRequest(
            name=version_name,
            update_mask=update_mask,
        )

        # Update the version configuration
        operation = client.update_version(request=update_request)

        # Wait for the operation to complete
        operation.result()

        logging.info(f"Successfully updated App Engine version '{version_id}' in service '{service_id}' to instance class '{instance_class}'.")
        print(f"Successfully updated App Engine version '{version_id}' to instance class '{instance_class}'.")

    except Exception as e:
        logging.error(f"Error occurred while updating App Engine version: {str(e)}")
        print(f"Error occurred while updating App Engine version: {str(e)}")

# Iterate over each row in the CSV file and inject values
for index, row in app_engine_data.iterrows():
    rightsize_app_engine_service(
        row['project_id'],
        row['service_id'],
        row['instance_class'],
        row['version_id'],
    )
