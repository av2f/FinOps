# Sogeti right-sizing library

This library acts as an accelerator

# Inside contains the GCP and Azure Scripts

# GCP Scripts

App Engine_GCP: Optimizing the instance class for larger processing needs and enhanced performance.​

Big Query_GCP: Adjusting datasets to incorporate additional tables for expanded data analysis.​

Cloud Spanner_GCP: Modifying the instance node count to ensure adequate capacity and performance.​

Compute Engine_GCP: Right-sizing the machine type to match workload requirements for cost efficiency.​

Disks_GCP: Scaling the storage capacity of current disks to accommodate growing data volumes.​

Kubernetes_GCP: Adjusting node pools within zones to balance workloads and maintain operational efficiency.​

Postgre DB_GCP: Upsizing PostgreSQL instances to handle increased transactional demands.​

SQL DB_GCP: Tailoring SQL database instances to better align with performance needs and cost management.​

VCP_GCP: Updating the subnet prefix to optimize virtual network configurations.​

# Azure Scripts

Application Service Plan (ASP)_Azure: Optimizing the size and scaling of hosting plans for web apps and services.​

Databricks_Azure: Adjusting cluster sizes and configurations for efficient big data processing.​

Virtual Networks_Azure: Scaling virtual networks for optimal connectivity and cost efficiency.​

OracleDb_Azure: Right-sizing Oracle database instances for performance and cost.​

SqlDB_Azure: Tailoring SQL database resources to meet demand while minimizing costs.​

CosmosDB_Azure: Scaling globally distributed databases to balance performance and pricing.​

MongoDB_Azure: Sizing MongoDB clusters to ensure efficient storage and retrieval.​

Container: Optimizing container resource allocations for application efficiency.​

Kubernetes_Azure: Right-sizing Kubernetes clusters to match workloads and reduce overhead.​

Disk_Azure: Allocating appropriate disk sizes and performance​ tiers for storage needs.​

​