import pandas as pd
from azure.identity import DefaultAzureCredential
from azure.mgmt.web import WebSiteManagementClient
import logging

# Configure logging
logging.basicConfig(filename='app_service_plan_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Create Azure client instance
credential = DefaultAzureCredential()
subscription_id = "Subscription_ID"
web_client = WebSiteManagementClient(credential, subscription_id)

# Read the CSV file
csv_file = 'app_service_plan_resizing.csv'
asp_data = pd.read_csv(csv_file)

# Function to resize an App Service Plan
def resize_app_service_plan(resource_group, service_plan_name, target_sku):
    try:
        logging.info(f"Attempting to resize App Service Plan '{service_plan_name}' in resource group '{resource_group}' to SKU '{target_sku}'")

        # Get the current service plan properties
        service_plan = web_client.app_service_plans.get(resource_group, service_plan_name)

        # Update the service plan SKU
        service_plan.sku.name = target_sku
        service_plan.sku.tier = target_sku.split('_')[0]  # Extract the tier from the SKU name (e.g., S1 -> Standard)

        # Update the service plan
        poller = web_client.app_service_plans.begin_create_or_update(resource_group, service_plan_name, service_plan)
        poller.result()  # Wait for the operation to complete
        logging.info(f"Successfully resized App Service Plan '{service_plan_name}' in resource group '{resource_group}' to SKU '{target_sku}'")

    except Exception as e:
        logging.error(f"Error resizing App Service Plan '{service_plan_name}': {str(e)}")

# Iterate over each row in the CSV file and resize App Service Plans
for index, row in asp_data.iterrows():
    resize_app_service_plan(
        row['resource_group'],
        row['service_plan_name'],
        row['target_sku']
    )
