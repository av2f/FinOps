import pandas as pd
from azure.identity import DefaultAzureCredential
from azure.mgmt.rdbms.postgresql import PostgreSQLManagementClient
from azure.mgmt.rdbms.postgresql.models import ServerUpdateParameters
import logging
import os

# Configure logging
logging.basicConfig(filename='postgresql_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Create Azure client instance
credential = DefaultAzureCredential()
subscription_id = os.environ.get("AZURE_SUBSCRIPTION_ID")
postgresql_client = PostgreSQLManagementClient(credential, subscription_id)

# Read the CSV file
csv_file = 'postgresql_db_resizing.csv'
db_data = pd.read_csv(csv_file)

# Function to resize a PostgreSQL Database
def resize_postgresql_db(resource_group, db_name, backup_retention_days):
    try:
        logging.info(f"Attempting to resize PostgreSQL Server '{db_name}' in resource group '{resource_group}'")

        # Get the PostgreSQL server
        server = postgresql_client.servers.get(resource_group, db_name)

        # Update the server SKU and other parameters
        update_params = ServerUpdateParameters(
            backup_retention_days=backup_retention_days
        )
        
        postgresql_client.servers.begin_update(resource_group, db_name, update_params).result()

        logging.info(f"Successfully resized PostgreSQL Server '{db_name}' to backup_retention_days '{backup_retention_days}'")
    except Exception as e:
        logging.error(f"Error resizing PostgreSQL Server '{db_name}': {str(e)}")

# Iterate over each row in the CSV file and resize PostgreSQL Servers
for index, row in db_data.iterrows():
    resize_postgresql_db(
        row['resource_group'], 
        row['db_name'],         
        row.get('backup_retention_days')
    )
