# Azure Scripts

# Prerequisites
-	pip install any necessary libraries 
-	Connect your Azure to run the scripts. There is multiple ways to do this (authenticate through user machine, authenticate through python code, etc.)
# directory structure
Each cloud service has 3 files
-	The python code (.py)
-	The excel file that has existing and new variables that get injected into the code (.csv)
-	A logging file that gives basic output information and helps track for debugging