import docker
import time
import pandas as pd
import logging

# Configure logging
logging.basicConfig(filename='container_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Docker client
client = docker.from_env()

# Function to get container statistics
def get_container_stats(container_name):
    container = client.containers.get(container_name)
    stats = container.stats(stream=False)
    
    # Extract CPU usage
    cpu_delta = stats['cpu_stats']['cpu_usage']['total_usage'] - stats['precpu_stats']['cpu_usage']['total_usage']
    system_cpu_delta = stats['cpu_stats']['system_cpu_usage'] - stats['precpu_stats']['system_cpu_usage']
    number_cpus = len(stats['cpu_stats']['cpu_usage']['percpu_usage'])
    cpu_usage = (cpu_delta / system_cpu_delta) * number_cpus
    
    # Extract memory usage
    memory_usage = stats['memory_stats']['usage']
    
    return cpu_usage, memory_usage

# Function to resize a container
def resize_container(container_name, new_cpu_limit, new_memory_limit):
    try:
        logging.info(f"Attempting to resize container '{container_name}' to CPU: {new_cpu_limit}, Memory: {new_memory_limit}MB")
        container = client.containers.get(container_name)
        container.update(cpu_quota=int(new_cpu_limit * 100000), mem_limit=f"{new_memory_limit}m")
        logging.info(f"Successfully resized container '{container_name}' to CPU: {new_cpu_limit}, Memory: {new_memory_limit}MB")
    except Exception as e:
        logging.error(f"Error resizing container '{container_name}': {str(e)}")

# Read the CSV file
csv_file = 'container_resizing.csv'
container_data = pd.read_csv(csv_file)

# Monitor and resize containers
for index, row in container_data.iterrows():
    container_name = row['container_name']
    observation_period = row['observation_period']  # in seconds
    logging.info(f"Monitoring container '{container_name}' for {observation_period} seconds")

    cpu_usages = []
    memory_usages = []

    # Monitor resource usage
    for _ in range(observation_period):
        cpu_usage, memory_usage = get_container_stats(container_name)
        cpu_usages.append(cpu_usage)
        memory_usages.append(memory_usage)
        time.sleep(1)

    # Calculate average usage
    avg_cpu_usage = sum(cpu_usages) / len(cpu_usages)
    avg_memory_usage = sum(memory_usages) / len(memory_usages) / (1024 * 1024)  # Convert bytes to MB

    # Suggest new limits
    suggested_cpu_limit = avg_cpu_usage * 1.2  # Add 20% buffer
    suggested_memory_limit = avg_memory_usage * 1.2  # Add 20% buffer

    logging.info(f"Suggested new limits for container '{container_name}': CPU: {suggested_cpu_limit} cores, Memory: {suggested_memory_limit} MB")

    # Resize container
    resize_container(resource_group, container_name, suggested_cpu_limit, suggested_memory_limit)
