import pandas as pd
from azure.identity import DefaultAzureCredential
from azure.mgmt.compute import ComputeManagementClient
import logging
import os

# Configure logging
logging.basicConfig(filename='disk_rightsizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Create Azure client instances
credential = DefaultAzureCredential()
subscription_id = "AZURE_SUBSCRIPTION_ID"
compute_client = ComputeManagementClient(credential, subscription_id)

# Read the CSV file
csv_file = 'disk_rightsizing.csv'
disk_data = pd.read_csv(csv_file)

# Function to resize a Managed Disk
def resize_managed_disk(resource_group, disk_name, target_sku):
    try:
        logging.info(f"Attempting to resize Managed Disk '{disk_name}' in resource group '{resource_group}' to SKU '{target_sku}'")

        # Get the Managed Disk
        disk = compute_client.disks.get(resource_group, disk_name)

        # Update the SKU and size
        target_size_gb = int(target_sku.split('_')[-1])
        target_sku_type = '_'.join(target_sku.split('_')[:-1])
        disk.sku.name = target_sku_type
        disk.disk_size_gb = target_size_gb

        # Update the Managed Disk
        compute_client.disks.begin_create_or_update(resource_group, disk_name, disk).result()

        logging.info(f"Successfully resized Managed Disk '{disk_name}' to SKU '{target_sku}'")
    except Exception as e:
        logging.error(f"Error resizing Managed Disk '{disk_name}': {str(e)}")

# Iterate over each row in the CSV file and resize Managed Disks
for index, row in disk_data.iterrows():
    resize_managed_disk(row['resource_group'], row['disk_name'], row['target_sku'])
