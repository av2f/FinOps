import pandas as pd
from azure.identity import DefaultAzureCredential
from azure.mgmt.network import NetworkManagementClient
import logging
import os

# Configure logging
logging.basicConfig(filename='vn_rightsizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Create Azure client instance
credential = DefaultAzureCredential()
subscription_id = "AZURE_SUBSCRIPTION_ID"
network_client = NetworkManagementClient(credential, subscription_id)

# Read the CSV file
csv_file = 'vn_rightsizing.csv'
vn_data = pd.read_csv(csv_file)

# Function to update a Virtual Network
def update_virtual_network(resource_group, vn_name, target_address_prefix=None, subnet_name=None, subnet_prefix=None):
    try:
        logging.info(f"Attempting to update Virtual Network '{vn_name}' in resource group '{resource_group}'")

        # Get the virtual network
        vnet = network_client.virtual_networks.get(resource_group, vn_name)
        
        # Update the address space if target_address_prefix is provided
        if target_address_prefix:
            vnet.address_space.address_prefixes = [target_address_prefix]

        # Update or add subnet if subnet details are provided
        if subnet_name and subnet_prefix:
            subnet = {
                'name': subnet_name,
                'address_prefix': subnet_prefix
            }
            # Check if subnet exists
            existing_subnet = next((s for s in vnet.subnets if s.name == subnet_name), None)
            if existing_subnet:
                existing_subnet.address_prefix = subnet_prefix
            else:
                vnet.subnets.append(subnet)

        # Update the virtual network
        network_client.virtual_networks.begin_create_or_update(resource_group, vn_name, vnet)
        logging.info(f"Successfully updated Virtual Network '{vn_name}' in resource group '{resource_group}'")

    except Exception as e:
        logging.error(f"Error updating Virtual Network '{vn_name}': {str(e)}")

# Iterate over each row in the CSV file and update Virtual Networks
for index, row in vn_data.iterrows():
    update_virtual_network(
        row['resource_group'],
        row['vn_name'],
        row.get('target_address_prefix'),
        row.get('subnet_name'),
        row.get('subnet_prefix')
    )
