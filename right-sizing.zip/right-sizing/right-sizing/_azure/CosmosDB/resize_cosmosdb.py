import pandas as pd
from azure.cosmos import CosmosClient, exceptions, ThroughputProperties
import logging

# Configure logging
logging.basicConfig(filename='cosmos_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Azure Cosmos DB client credentials
endpoint = "YOUR_COSMOSDB_ENDPOINT"
key = "YOUR_COSMOSDB_KEY"

# Create Cosmos client instance
cosmos_client = CosmosClient(endpoint, key)

# Read the CSV file
csv_file = 'cosmos_db_resizing.csv'
db_data = pd.read_csv(csv_file)

# Function to resize or provision a Cosmos DB container throughput
def resize_cosmos_db(resource_group, database_name, container_name, target_throughput):
    try:
        logging.info(f"Attempting to resize Cosmos DB container '{container_name}' in database '{database_name}' to throughput '{target_throughput}'")

        # Get the database and container
        database = cosmos_client.get_database_client(database_name)
        container = database.get_container_client(container_name)

        # Ensure target_throughput is an integer
        target_throughput = int(target_throughput)

        # Try to read the current throughput offer
        try:
            offer = container.read_offer()
            if offer:
                current_throughput = offer.properties.get('content').get('offerThroughput')
            else:
                current_throughput = None
        except exceptions.CosmosResourceNotFoundError:
            logging.info(f"Container '{container_name}' does not have dedicated throughput. Provisioning throughput...")

            try:
                # Check if the database has throughput
                database_offer = database.read_offer()
                if database_offer:
                    current_throughput = database_offer.properties.get('content').get('offerThroughput')
                    if current_throughput != target_throughput:
                        database.replace_throughput(ThroughputProperties(offer_throughput=target_throughput))
                        logging.info(f"Successfully resized Cosmos DB database '{database_name}' to throughput '{target_throughput}'")
                    else:
                        logging.info(f"Cosmos DB database '{database_name}' already has throughput '{target_throughput}'. No action needed.")
                else:
                    logging.error(f"No throughput settings found for database '{database_name}'.")
            except exceptions.CosmosResourceNotFoundError:
                logging.error(f"No throughput settings found for database '{database_name}' or container '{container_name}'.")

            return

        # Replace the throughput if different
        if current_throughput != target_throughput:
            container.replace_throughput(ThroughputProperties(offer_throughput=target_throughput))
            logging.info(f"Successfully resized Cosmos DB container '{container_name}' to throughput '{target_throughput}'")
        else:
            logging.info(f"Cosmos DB container '{container_name}' already has throughput '{target_throughput}'. No action needed.")

    except Exception as e:
        logging.error(f"Error resizing Cosmos DB container '{container_name}': {str(e)}")

# Iterate over each row in the CSV file and resize or provision Cosmos DB containers
for index, row in db_data.iterrows():
    resize_cosmos_db(
        row['resource_group'],
        row['database_name'],
        row['container_name'],
        row['target_throughput']
    )
