import pandas as pd
from azure.identity import DefaultAzureCredential
from azure.mgmt.sql import SqlManagementClient
import logging
import os

# Configure logging
logging.basicConfig(filename='sql_resizing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Create Azure client instance
credential = DefaultAzureCredential()
subscription_id = "AZURE_SUBSCRIPTION_ID"
sql_client = SqlManagementClient(credential, subscription_id)

# Read the CSV file
csv_file = 'sql_db_resizing.csv'
db_data = pd.read_csv(csv_file)

# Function to resize a SQL Database
def resize_sql_db(resource_group, server_name, db_name, target_sku, target_tier):
    try:
        logging.info(f"Attempting to resize SQL Database '{db_name}' in resource group '{resource_group}' to SKU '{target_sku}'")

        # Get the SQL Database
        db = sql_client.databases.get(resource_group_name=resource_group, server_name=server_name, database_name=db_name)

        # Update the database SKU
        db.sku.name = target_sku
        db.sku.tier = target_tier

        # Update the database
        sql_client.databases.begin_create_or_update(resource_group_name=resource_group, server_name=server_name, database_name=db_name, parameters=db).result()


        logging.info(f"Successfully resized SQL Database '{db_name}' to SKU '{target_sku}'")
    except Exception as e:
        logging.error(f"Error resizing SQL Database '{db_name}': {str(e)}")

# Iterate over each row in the CSV file and resize SQL Databases
for index, row in db_data.iterrows():
    resize_sql_db(row['resource_group'],row['server_name'], row['db_name'], row['target_sku'], row['target_tier'])
